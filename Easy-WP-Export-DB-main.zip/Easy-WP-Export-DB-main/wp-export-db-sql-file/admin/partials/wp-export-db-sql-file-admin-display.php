<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       github.com/abuzer
 * @since      1.0.0
 *
 * @package    Wp_Export_Db_Sql_File
 * @subpackage Wp_Export_Db_Sql_File/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
