=== Easy WP Export DB ===
Contributors: firdousi
Donate link: github.com/abuzer
Tags: export, backup, backup database, WordPress backup database, WordPress backup DB 
Requires at least: 5.0.1
Tested up to: 5.5.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A easy way to download the database backup in SQL file.

== Description ==

Sometime it is a bit hard to download the database for development purpose or for migrating site quickly. 

Your suggestions are welcome to make this plugin more useful.


== Installation ==

1. Upload `wp-export-db-sql-file.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Navigate to Tools > Export DB

== Changelog ==

= 1.0 =
* Inital plugin version
